#include<iostream>
#include<queue>
struct BinTreeNode {
	int data;
	struct BinTreeNode *leftChild, *rightChild;
};
class BinaryTree {
private:
	BinTreeNode *root;
public:
	void  create_tree()
	{//������빹�������
		int pa, lch, rch;
		BinTreeNode  *q, *temp;
		std::queue<BinTreeNode *> qu;
		std::cin >> pa;//���ڵ�
		if (pa != -1)
		{
			root = new BinTreeNode;
			root->data = pa;
			root->leftChild = root->rightChild = NULL;
			qu.push(root);
		}
		while (!qu.empty())
		{
			temp = qu.front();
			qu.pop();
			std::cin >> lch;
			if (lch == -2)//����-2��ֹ
				return;
			if (lch != -1)//������
			{
				q = new BinTreeNode;
				q->data = lch;
				q->leftChild = NULL;
				q->rightChild = NULL;
				temp->leftChild = q;
				qu.push(q);
			}
			else temp->leftChild = NULL;
			std::cin >> rch;
			if (rch == -2)
				return;
			if (rch != -1)//������
			{
				q = new BinTreeNode;
				q->data = rch;
				q->leftChild = NULL;
				q->rightChild = NULL;
				temp->rightChild = q;
				qu.push(q);
			}
			else temp->rightChild = NULL;
		}
	}
	BinTreeNode* getRoot()
	{
		return root;
	}
	bool findx(BinTreeNode *r, int x)//ǰ������ж�x�Ƿ�Ϊ����ڵ�
	{
		if (r != NULL)
		{
			if (r->data == x)
				return 1;
			else
			{
				int i1 = 0;
				int i2 = 0;
				if (r->leftChild != NULL)
					i1=findx(r->leftChild, x);
				if (i1 == 1)
					return 1;
				else
				{
					if (r->rightChild != NULL)
						i2 = findx(r->rightChild, x);
				}
				if (i2 == 1)
					return 1;
				else return 0;
			}
		}
	}
		/*BinTreeNode *q;
		std::queue<BinTreeNode *>	que;
		que.push(r);
		while (!que.empty())
		{
			q = que.front();
			que.pop();
			if (q->leftChild != NULL)
				que.push(q->leftChild);
			if (q->rightChild != NULL)
				que.push(q->rightChild);
			if (q->data == x)
				return 1;
		}*/
	bool isparent(BinTreeNode *r,int a, int b)//�ж��Ƿ�ͬʱΪ�����ڵ������
	{
		if (findx(r,a) && findx(r,b))
			return 1;
		else return 0;
	}
	bool isnearest(BinTreeNode *r, int a, int b)//�ж��Ƿ�Ϊ���������
	{
		if (!isparent(r, a, b))
			return 0;
		else if (r->data == a || r->data == b || r->leftChild->data == a&&r->rightChild->data == b || r->leftChild->data == b&&r->rightChild->data == a)
			return 1;
		else return 0;
	}
	int findCommonParent(BinTreeNode *r, int a, int b)//�ҵ���С�������ڵ�
	{
		if (isnearest(r, a, b))
			return r->data;
		else
		{
			if (isparent(r->leftChild, a, b))
				findCommonParent(r->leftChild, a, b);
			else if (isparent(r->rightChild, a, b))
				findCommonParent(r->rightChild, a, b);
			else return r->data;
		}
	}
		/*if (r->data == a&&findx(r, b))//���aΪ��ͬ���ڵ㣬���a
			return r->data;
		if (r->data == b&&findx(r, a))//���bΪ��ͬ���ڵ㣬���b
			return r->data;
		else//���a��b��Ϊ����ڵ�
		{
			
			int parent;//�洢parent��ֵ
			//��α����ҹ�ͬ����,�ҵ�һ��������parent
			std::queue<BinTreeNode *> que;
			BinTreeNode *q;
			que.push(r);
			while (!que.empty())
			{
				q = que.front();
				que.pop();
				if (q->leftChild != NULL)
					que.push(q->leftChild);
				if (q->rightChild != NULL)
					que.push(q->rightChild);
				if (isparent(q, a, b))
					parent = q->data;
			}
			return parent;
		}*/
};