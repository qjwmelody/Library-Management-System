#include<iostream>
#include<queue>
#include<stack>
struct BinTreeNode {
	int data;
	struct BinTreeNode *leftChild, *rightChild;
};
class BinaryTree {
private:
	BinTreeNode *root;
public:
	void  create_tree()
	{//������빹�������
		int pa, lch, rch;
		BinTreeNode  *q, *temp;
		std::queue<BinTreeNode *> qu;
		std::cin >> pa;//���ڵ�
		if (pa != -1)
		{
			root = new BinTreeNode;
			root->data = pa;
			root->leftChild = root->rightChild = NULL;
			qu.push(root);
		}
		while (!qu.empty())
		{
			temp = qu.front();
			qu.pop();
			std::cin >> lch;
			if (lch == -2)//����-2��ֹ
				return;
			if (lch != -1)//������
			{
				q = new BinTreeNode;
				q->data = lch;
				q->leftChild = NULL;
				q->rightChild = NULL;
				temp->leftChild = q;
				qu.push(q);
			}
			else temp->leftChild = NULL;
			std::cin >> rch;
			if (rch == -2)
				return;
			if (rch != -1)//������
			{
				q = new BinTreeNode;
				q->data = rch;
				q->leftChild = NULL;
				q->rightChild = NULL;
				temp->rightChild = q;
				qu.push(q);
			}
			else temp->rightChild = NULL;
		}
	}
	BinTreeNode* getRoot()
	{
		return root;
	}
	void open(BinTreeNode *r)//��������չ�����������ݹ�ʵ�֣�
	{
		if(r->leftChild!=NULL)
			open(r->leftChild);
		if(r->rightChild!=NULL)
			open(r->rightChild);
		if (r->leftChild!=NULL&&r->leftChild->leftChild == NULL)//�ҵ����½ǽڵ�ĸ�ĸ�ڵ�
		{//���ýڵ�����Ӳ��뵽�Һ�����
			BinTreeNode *p = r->leftChild;
			BinTreeNode *q = r->rightChild;
			r->rightChild = p;
			while (p->rightChild != NULL)
				p = p->rightChild;
			p->rightChild = q;
			r->leftChild = NULL;
		}
	}
	void open2(BinTreeNode *r)//�ǵݹ�ʵ��
	{
		std::stack<BinTreeNode *> stk;
		BinTreeNode *p;
		while (r!=NULL||!stk.empty())
		{
			while (r != NULL)//��;���Ľڵ�ѹ��ջ��
			{
				stk.push(r);
				r = r->leftChild;
			}
			p = stk.top();
			stk.pop();//ȡ��ջ��
			if (p->leftChild != NULL)
				stk.push(p->leftChild);
			if (p->rightChild != NULL)
				stk.push(p->rightChild);//�����Һ���ѹ��ջ��
			if (p->leftChild != NULL&&p->leftChild->leftChild == NULL)//��ݹ��㷨��ͬ
			{
				BinTreeNode *m = p->leftChild;
				BinTreeNode *n = p->rightChild;
				p->rightChild = m;
				while (m->rightChild != NULL)
					m = m->rightChild;
				m->rightChild = n;
				p->leftChild = NULL;
			}
		}
	}
	void print()//��ӡ
	{
		while (root != NULL)
		{
			std::cout << root->data<<' ';
			root = root->rightChild;
		}
	}
};