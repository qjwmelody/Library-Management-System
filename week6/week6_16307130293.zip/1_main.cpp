#include<iostream>
#include<string>
#include<vector>

using namespace std;

void brackets(int left,int right,string s,vector<string>&  store)
{
	if (left == 0 && right == 0)
		store.push_back(s);
	else
	{
		if (left != 0)
			brackets(left - 1, right, s + '(',store);
		if (right != 0 && right >left)
			brackets(left, right - 1, s + ')',store);
	}
}
int main()
{
	int n;
	cout << "���������Ŷ���n:";
	cin >> n;
	cout << "���п��ܵ����Ϊ:" << '[';
	string s;
	vector<string> store;
	brackets(n, n, s,store);
	for (int i = 0; i != store.size(); i++)
	{
		cout << store[i];
		if (i != store.size() - 1)
			cout << ',';
	}
	cout << ']' << endl;
	system("pause");
	return 0;
}