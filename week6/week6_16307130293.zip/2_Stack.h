#include<iostream>
struct State {	//״̬
	int n,A, B, C;
	State() { n = A = B = C = 0; }
	State(int n1, int A1, int B1, int C1) { n = n1; A = A1; B = B1; C = C1; }
};
class Stack {	
private:
	int top=-1;
	State *store;
public:
	Stack() { store = new State[1000]; }
	void push(State *s)	//��ջ
	{
		store[++top] = *s;
	}
	int pop(State &p)	//��ջ
	{
		if (top == -1) return 1;
		else
		{
			p = store[top--];
			return 0;
		}
	}
};