#include<iostream>
template<class Type>struct Node{
	Type data;
	struct Node *link;
};
template<class Type> class Queue;
template<class Type> 
class Stack{
	friend class Queue<Type>;//��������Ϊջ��Ԫ
private:
	Node<Type> *top;
public:
	Stack(){top=NULL;}
	void add(Type x)
	{
		Node<Type> *p;
		p=(Node<Type> *)malloc(sizeof(Node<Type>));
		p->data=x;
		p->link=top;
		top=p;
	}
	int poll(Type &x)
	{
		Node<Type> *p;
		if(top==NULL) return 1;
		else
		{
			x=top->data;
			p=top;
			top=top->link;
			delete p;
			return 0;
		}
	}
	void printStack()
	{
		Node<Type> *p = top;
		while (p != NULL)
		{
			std::cout << p->data << ' ';
			p = p->link;
		}
	}
};
template<class Type> 
class Queue{
private:
	Stack<Type> sta1,sta2;
public:
	bool peek()//�п�
	{
		if(sta1.top==NULL&&sta2.top==NULL) 
		{
			std::cout<<"true"<<endl;
			return 1;
		}
		else 
		{
			std::cout<<"false"<<endl;
			return 0;
		}
	}
	void add(Type x)//����
	{
		sta1.add(x);
		std::cout << "true" << endl;
	}
	int poll(Type &x)//����
	{
		if (sta1.top == NULL&&sta2.top == NULL)//��ջ��Ϊ��
		{
			std::cout << "false" << endl;
		}
		else
		{
			if(sta2.top!=NULL)//ջ2��Ϊ�գ���ջ
			{
				sta2.poll(x);
			}
			else
			{
				while (sta1.top->link != NULL)//��ջ1����ѹ��ջ2��ʣ��ջ��Ԫ��
				{
					sta2.add(sta1.top->data);
					sta1.poll(x);
				}
				sta1.poll(x);//ջ1ջ��Ԫ�س�ջ
			}
			std::cout << "true" << endl;
			return 0;
		}
	}
	void printQueue()//��ӡ
	{
		sta2.printStack();
		Node<Type> *p=sta1.top;
		Stack<Type> sta3;
		while(p!=NULL)
		{
			sta3.add(p->data);
			p = p->link;
		}
		sta3.printStack();
		std::cout << endl;
	}
};