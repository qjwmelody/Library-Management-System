#include<iostream>
#include<string>
#include"Queue.h"
using namespace std;
int main()
{
	cout << "���������" << endl;
	Queue<int> queue;
	string s;
	int x;
	while(cin>>s&&s!="end")
	{
		if(s[0]==112)
		{
			switch(s[1])
			{
				case 101:
				{
					queue.peek();
					break;
				}
				case 111:
				{
					queue.poll(x);
					break;
				}
				case 114:
				{
					queue.printQueue();
					break;
				}
				default:cout<<"wrong input!"<<endl;
			}
		}
		else if(s[0]==97)
		{
			int value;
			cin >> value;
			queue.add(value);
		}
	}
	cout << "�������!"<<endl;
	system("pause");
	return 0;
}