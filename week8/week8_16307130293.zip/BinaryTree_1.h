#include<iostream>
template<class Type>class BinaryTree;
template<class Type>
class BinTreeNode {		//�����
	friend class BinaryTree<Type>;
private:
	Type data;
	BinTreeNode<Type> *leftChild, *rightChild;
public:
	BinTreeNode() :leftChild(NULL), rightChild(NULL) {}
	BinTreeNode(Type item, BinTreeNode<Type> *left = NULL, BinTreeNode<Type> *right = NULL) :data(item), leftChild(left), rightChild(right) {}
};

template<class Type>
class BinaryTree {		//������
private:
	BinTreeNode<Type> *root;
public:
	BinaryTree() { root=NULL; }
	void destroy(BinTreeNode<Type> *subTree)
	{
		if (subTree != NULL)
		{
			destroy(subTree->leftChild);
			destroy(subTree->rightChild);
			delete subTree;
		}
	}
	~BinaryTree()
	{
		destroy(root);
	}
	 void Create_Tree(std::istream& in)
	{//�ù������ʽ���������
		BinTreeNode <Type>*st[100]; //st�����൱��ջ
		BinTreeNode <Type>*p;
		int top = -1;
		int k;
		char ch;
		while (in >> ch)
		{
			switch (ch)
			{
			case '(':
			{
				top++;
				st[top] = p;
				k = 1;
				break;
			}
			case ',':
			{
				k = 2;
				break;
			}
			case ')':
			{
				top--;
				break;
			}
			default:
			{
				p = new BinTreeNode<Type>;
				p->data = ch-48;
				p->leftChild = p->rightChild = NULL;
				if (root== NULL)
					root = p;
				else
				{
					if (k == 1) { st[top]->leftChild = p; }
					else { st[top]->rightChild = p; }
				}
			}
			}
		}
	}
	BinTreeNode<Type> *getRoot() const { return root; }

	int sum(BinTreeNode<Type>* temp)
	{//�ݹ�ʵ�����
		if (temp == NULL) return 0;
		else if (temp->leftChild !=NULL&& temp->leftChild->leftChild==NULL && temp->leftChild->rightChild==NULL)
			return temp->leftChild->data + sum(temp->rightChild);
		else return sum(temp->leftChild) + sum(temp->rightChild);
	}
}; 
