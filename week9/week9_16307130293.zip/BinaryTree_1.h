#include<iostream>
#include<queue>
struct BinTreeNode {
	int data;
	struct BinTreeNode *leftChild, *rightChild;
};
class BinaryTree {
private:
	BinTreeNode *root;
public:
	void  create_tree()
	{//������빹�������
		int pa, lch, rch;
		BinTreeNode  *q, *temp;
		std::queue<BinTreeNode *> qu;
		std::cin >> pa;//���ڵ�
		if (pa != 0)
		{
			root = new BinTreeNode;
			root->data = pa;
			root->leftChild = root->rightChild = NULL;
			qu.push(root);
		}
		while (!qu.empty())
		{
			temp = qu.front();
			qu.pop();
			std::cin >> lch;
			if (lch == -1)//����-1��ֹ
				return;
			if (lch != 0)//������
			{
				q = new BinTreeNode;
				q->data = lch;
				q->leftChild = NULL;
				q->rightChild = NULL;
				temp->leftChild = q;
				qu.push(q);
			}
			else temp->leftChild = NULL;
			std::cin >> rch;
			if (rch != 0)//������
			{
				q = new BinTreeNode;
				q->data = rch;
				q->leftChild = NULL;
				q->rightChild = NULL;
				temp->rightChild = q;
				qu.push(q);
			}
			else temp->rightChild = NULL;	
		}
	}
	void average() 
	{//���ÿ��ƽ��ֵ
		if (root != NULL)
		{
			std::queue<BinTreeNode *> qu;
			qu.push(root);
			while (!qu.empty())
			{
				int num = qu.size();//numΪ��ǰ��Ľڵ���
				long temp = 0;
				for (int i = 0; i != num; i++)
				{
					BinTreeNode *f =qu.front();
					qu.pop();
					if (f == NULL)
						return;
					else
					{
						if (f->leftChild != NULL)
								qu.push(f->leftChild);
						if (f->rightChild != NULL)
								qu.push(f->rightChild);
						temp += f->data;
					}
				}
				std::cout << double (temp) / num<<' ';
			}
		}
	}
};